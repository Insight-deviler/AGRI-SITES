package com.agri.helper;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class MainActivity extends Activity {
	
	
	private ScrollView vscroll1;
	private LinearLayout linear15;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear17;
	private Button button2;
	private Button button1;
	private Button button3;
	private Button button12;
	private Button button4;
	private Button button5;
	private Button button6;
	private Button button8;
	private Button button9;
	private Button button11;
	private Button button7;
	private Button button10;
	
	private Intent entomology = new Intent();
	private Intent pathology = new Intent();
	private Intent sac = new Intent();
	private Intent gpb = new Intent();
	private Intent agronomy = new Intent();
	private Intent horticulture = new Intent();
	private Intent micro = new Intent();
	private Intent economic = new Intent();
	private Intent aeg = new Intent();
	private Intent extension = new Intent();
	private Intent math = new Intent();
	private Intent supporting = new Intent();
	private Intent GPAcalculator = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		button2 = (Button) findViewById(R.id.button2);
		button1 = (Button) findViewById(R.id.button1);
		button3 = (Button) findViewById(R.id.button3);
		button12 = (Button) findViewById(R.id.button12);
		button4 = (Button) findViewById(R.id.button4);
		button5 = (Button) findViewById(R.id.button5);
		button6 = (Button) findViewById(R.id.button6);
		button8 = (Button) findViewById(R.id.button8);
		button9 = (Button) findViewById(R.id.button9);
		button11 = (Button) findViewById(R.id.button11);
		button7 = (Button) findViewById(R.id.button7);
		button10 = (Button) findViewById(R.id.button10);
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				gpb.setAction(Intent.ACTION_VIEW);
				gpb.setClass(getApplicationContext(), GpbActivity.class);
				startActivity(gpb);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				entomology.setAction(Intent.ACTION_VIEW);
				entomology.setClass(getApplicationContext(), EntomologyActivity.class);
				startActivity(entomology);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				agronomy.setAction(Intent.ACTION_VIEW);
				agronomy.setClass(getApplicationContext(), AgronomyActivity.class);
				startActivity(agronomy);
			}
		});
		
		button12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pathology.setAction(Intent.ACTION_VIEW);
				pathology.setClass(getApplicationContext(), PathologyActivity.class);
				startActivity(pathology);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sac.setAction(Intent.ACTION_VIEW);
				sac.setClass(getApplicationContext(), SoilScienceActivity.class);
				startActivity(sac);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				micro.setAction(Intent.ACTION_VIEW);
				micro.setClass(getApplicationContext(), MicrobiologyActivity.class);
				startActivity(micro);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				economic.setAction(Intent.ACTION_VIEW);
				economic.setClass(getApplicationContext(), EconomicsActivity.class);
				startActivity(economic);
			}
		});
		
		button8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				horticulture.setAction(Intent.ACTION_VIEW);
				horticulture.setClass(getApplicationContext(), HorticultureActivity.class);
				startActivity(horticulture);
			}
		});
		
		button9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				extension.setAction(Intent.ACTION_VIEW);
				extension.setClass(getApplicationContext(), ExtensionActivity.class);
				startActivity(extension);
			}
		});
		
		button11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				supporting.setAction(Intent.ACTION_VIEW);
				supporting.setClass(getApplicationContext(), SupportingcourseActivity.class);
				startActivity(supporting);
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				aeg.setAction(Intent.ACTION_VIEW);
				aeg.setClass(getApplicationContext(), AgriEngineeringActivity.class);
				startActivity(aeg);
			}
		});
		
		button10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				math.setAction(Intent.ACTION_VIEW);
				math.setClass(getApplicationContext(), MathStatComputerActivity.class);
				startActivity(math);
			}
		});
	}
	private void initializeLogic() {
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
